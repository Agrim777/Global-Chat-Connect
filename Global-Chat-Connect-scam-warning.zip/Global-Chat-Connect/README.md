# 🌍 Global Chat Connect — WorldMatch Dating Bot

A Telegram-based global matchmaking bot that connects users from around the world.

---

## ⚠️ SCAM WARNING — PLEASE READ BEFORE USING ⚠️

> **We have received multiple complaints from users who were scammed.**
> **Please read this section carefully before engaging with anyone on this platform.**

### 🚨 DO NOT PAY ANYONE FOR VIDEO CALLS

There are **fake accounts** and **scam operators** active on chat platforms who pose as real users and ask for money in exchange for:

- 💸 Paid "live" video calls
- 💸 Paid "private" or "premium" video chats
- 💸 Any form of explicit/vulgar content

**These are scams. You WILL lose your money and receive nothing.**

---

### ❌ NEVER send money to someone you met on this bot for:

| Request | Reality |
|--------|---------|
| "Pay me and I'll do a live video call" | ❌ SCAM — they will block you after payment |
| "I'll show you something if you send money" | ❌ SCAM — never happens |
| "Pay for premium access to chat with me" | ❌ SCAM — this bot does not work this way |
| "Send me gift cards / crypto / UPI" | ❌ SCAM — no legitimate user asks for this |

---

### 🛡️ HOW TO PROTECT YOURSELF

1. **Never send money** to any person you meet through this bot — not for video calls, not for photos, not for "unlocking" anything.
2. **Report suspicious accounts** immediately using the bot's report feature or by contacting the admins.
3. **Do not share** your personal phone number, address, or financial details with strangers.
4. **Be sceptical** of anyone who quickly becomes affectionate and then asks for money. This is a classic romance scam pattern.
5. **Real connections don't cost money.** If someone demands payment to continue talking, they are scamming you.

---

### 📢 Real Incidents We Know About

We have verified reports of users being scammed **multiple times** by individuals who:
- Pretended to be genuine matches
- Built trust over a few days of chat
- Then demanded payment for video calls
- Blocked the user immediately after receiving money

**Do not let this happen to you.**

---

### 📞 Report a Scam

If you have been scammed or encountered suspicious activity:

- Screenshot the conversation
- Report it to your local cybercrime authority
- In India: [cybercrime.gov.in](https://cybercrime.gov.in)
- Contact the bot admin to have the account removed

---

## About

This bot is designed for **genuine connections only**. We do not facilitate or endorse any paid content, explicit material, or monetary transactions between users.

**Stay safe. Stay smart. Real love doesn't have a price tag.**

---

*WorldMatch Team*
